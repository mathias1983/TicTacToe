/**
 * Created by mathias on 19.10.2014.
 */
public class Config {

    // Breite des Spielfeldes in Spalten
    public static final int fieldCountWidth  = 3;
    // Höhe des Spielfeldes in Zeilen
    public static final int fieldCountHeight = 3;

}
